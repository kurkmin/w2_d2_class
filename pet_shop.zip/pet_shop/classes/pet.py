class Pet:
    def __init__(self, name, type, breed, price):
        self.name = name
        self.type = type
        self.breed = breed
        self.price = price
